# menu2rss

 Tool to scrape menu and convert it to a RSS feed (for use with Xibo dispay).
 Feed: https://joenblan.github.io/menu2rss/menu_feed.xml
